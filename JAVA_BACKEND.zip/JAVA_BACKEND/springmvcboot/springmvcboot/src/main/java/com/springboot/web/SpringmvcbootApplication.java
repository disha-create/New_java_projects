package com.springboot.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringmvcbootApplication {
	public static void main(String[] args) {
		SpringApplication.run(SpringmvcbootApplication.class, args);
	}
}
